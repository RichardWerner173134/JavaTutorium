package main;

public class Main {

	public static void main(String[] args) {
		
		int laenge = 5;
			
		double[] feld = array.SimpleArray.erstelleFeld(laenge);

		System.out.println(array.SimpleArray.minElement(feld));
		System.out.println(array.SimpleArray.maxElement(feld));
		
		array.SimpleArray.druckeFeld(feld);
		
		
		System.out.println(array.SimpleArray.berechneDurchschnitt(feld));
		System.out.println(array.SimpleArray.bestimmeKleinstenAbstand(feld));
		
		for(int i = 0; i < feld.length; i++) {
			int x = (int)feld[i];
			String string = String.valueOf(x);
			char[] zahl = string.toCharArray();
			System.out.println(array.SimpleArray.berechneQuersumme(zahl));
		}
		
		array.SimpleArray.sortArray(feld);
		
	}
		
}


