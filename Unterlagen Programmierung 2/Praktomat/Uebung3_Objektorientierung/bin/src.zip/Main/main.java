package Main;

import shop.Artikel;
import shop.Kunde;

public class main {
	
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
		try {
		Kunde p = new Kunde (" Peter ");	
		Artikel d = new Artikel ("Deo " ,100) ;
		p. kauft (d);
		p. kauft (new Artikel (" Kette " ,100));
		p. kauft (d);
		p. kauft (new Artikel (" Kette " ,100));
		p.getWkorb().remove(d);
		p. kauft (d);
		p.getWkorb().remove(d);
		p. kauft (d);

		p. kauft (new Artikel (" Kette " ,100));
		int petersAnzahl = p. getWkorb (). getAnzahl ();
		System . out. println ( petersAnzahl );
		int petersAnzahl2 = p. getWkorb (). anzahl ;
		System . out. println ( petersAnzahl2 );
		String petersRechnungsText ;
		double petersPreis = p. bezahlt ();

		petersRechnungsText = p. getName() + " bezahlt " + petersPreis + "fuer " + petersAnzahl + " Artikel .";
		System.out.println(petersRechnungsText);
		}
		catch(NullPointerException e) {
		}
	}
}
