package shop;

public class Kunde {
	private String name;
	private Warenkorb wkorb;
	
	
	public Kunde(String name) {
		this.name = name;
		this.wkorb = new Warenkorb();
	}
	
	public Warenkorb getWkorb() {
		return this.wkorb;
	}
	
	public String getName() {
		return this.name;
	}
	
	
	public void kauft(Artikel a) {
		if(a==null);
		wkorb.add(a);
	}
	
	
	public double bezahlt() {
		try {
		
		double kosten = wkorb.getSumme();
		
		if (kosten>=100) {}
		else if(kosten>=30) {
			kosten = kosten*1.03;
		}
		else if(kosten>=10) {
			kosten = kosten+4;
		}
		else if(kosten > 0){
			kosten = kosten+6;
		}
		else {kosten = 0 ;}
		
		kosten = Math.round(kosten*100)/100.0;
		return kosten;
		}
		catch(NullPointerException e) {
			return 0;
		}
	}
}
