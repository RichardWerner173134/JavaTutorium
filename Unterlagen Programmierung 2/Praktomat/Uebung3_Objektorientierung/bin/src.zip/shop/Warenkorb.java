package shop;


public class Warenkorb {
	
	public int anzahl = 0;
	
	private Artikel artFeld[]=new Artikel[100];
	
	public void add(Artikel a) {
		if(a != null) {
			if(anzahl < 100) {
				artFeld[anzahl]=a;
				anzahl ++;
			}
		}
	}
	
	public double getSumme() {
		try {
			
		double summe = 0;
		int counter = anzahl;
		for (int i=0; i<counter; i++) {
			summe = summe + artFeld[i].getPreis();
		}
		return summe;
		}
		catch(NullPointerException e) {
			return 0;
	}
		
		
}


	public int getAnzahl() {
		int werte = 0;
		for(int i=0;i<artFeld.length; i++) {
			if (artFeld[i]!= null) {
				werte = werte + 1;
			}
			else if(artFeld[i]== null) {}
			
		}
		this.anzahl = werte;
		return werte;
	}
	
	
	
	
	
	public void remove(Artikel a) {
		try {
			
			
		String bez = a.getBezeichnung();
		Double pre = a.getPreis();
		
	
	
		
			for(int i = 0 ; i < 100; i++) {
			
		for (int j=0; j<this.anzahl; j++)
		{ 
			String bez2 = artFeld[j].getBezeichnung();
			Double pre2 = artFeld[j].getPreis();
			
			if(bez.equals(bez2)&&pre2.equals(pre) )
			{
				
				artFeld[j] = artFeld[anzahl -1];
				this.artFeld[anzahl - 1] = null;				
				this.anzahl = anzahl - 1;
				
				
			}
			
			}}
			this.anzahl = this.getAnzahl();
		}catch(NullPointerException e) {};
		}
	}
	
	

	
	



